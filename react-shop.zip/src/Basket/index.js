import React from "react";

export default class Basket extends React.Component{
    render(){

    	
        return (
			<div className="basket">
				Basket component
				<ul className="good-list">
					<li></li>
				</ul>
			</div>
        )
    }
}